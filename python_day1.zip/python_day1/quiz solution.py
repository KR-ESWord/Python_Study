#1-9 리스트 0으로 초기화
#start index와 end index를 입력받으시오
#만약 2, 5를 입력 받았다면 index 2-5까지 배열 값을 1씩 증가 시키면 됩니다
#입력은 총 5번 받는다
'''
#step1
def input_num():
    global ii
    global ee
    ii = int(input('start index : '))
    ee = int(input('end index : '))
        
def calc_list():
    for i in range(ii, ee + 1, 1):
        q_list[i] = q_list[i] + 1
    print(q_list)
    
q_list = [0,0,0,0,0,0,0,0,0]
a = 1
while a < 5 :
    input_num()
    if ee < ii :
        print('올바르지 않은 값입니다.')
        continue
    calc_list()
    a += 1
'''
#Y가 존재 합니까?
#세 문장을 입력받고 이 문장에 Y라는 글자가 존재하는지 찾아 출력 해 주세요.
#(각 문장당 최대 10글자)
#함수를 이용하여 찾아 주세요.
#Y를 찾으셨다면 Y가 존재합니다
#Y를 찾지 못하였다면 Y가 존재하지 않습니다
#를 출력해주세요

#step2
'''
def search() :  
    if q_list.count('Y') > 0 :
        print('Y가 존재 합니다.')
    else :
        print('Y가 존재하지 않습니다.')

while True :
    q = input('문장 입력 : ')
    q_list = q
    search()
'''
#step3

def search() :
    while True :
        if q_list.count(',') != 0 :
            slicing = q_list[:q_list.index(',')]
            if slicing.count('Y') != 0 :
                print('Y가 존재 합니다.')
                q_list[:(q_list.index(',') + 1)] = []
            else :
                print('Y가 존재 하지 않습니다.')
                q_list[:(q_list.index(',') + 1)] = []
        else :
            break

q_list =[]
a = input()
q_list.extend(a)
print(q_list)
q_list.extend([','])
print(q_list)
search()

