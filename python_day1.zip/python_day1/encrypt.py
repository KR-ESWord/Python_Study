#입력 받을 리스트 내용
low = 'abcdefghijklmnopqrstuvwxyz'
high = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
emo1 = ' !"#$%&\'()*+,-./'
emo2 = '0123456789:;<=>?'
answer = ''

#start함수
def start():
    while True :
        s_mode = input('mode입력(e(encrypt) or d(decrypt) or s(stop) : ')
        if s_mode == 'e':
            print('암호화를 시작합니다.')
            encrypt(answer)
            
        elif s_mode == 'd':
            print('복호화를 시작합니다.')
            decrypt(answer)

        elif s_mode == 's':
            print('프로그램이 종료되었습니다.')
            break

        else :
            print('mode입력을 잘 못하셨습니다.')

#암호화 함수
def encrypt(answer) :
    m = input('message 입력 : ')
    k = int(input('key 입력 : '))
    for i in m :
        #message의 값 i가 입력된 경우의 수로 진행
        #i의 값을 경우의 수의 리스트의 인덱스(수) 값에
        #key값을 더한 후 26의 나머지의 값을
        #암호화할 리스트의 인덱스 값(문자)을 answer에 대입
        if low.count(i) != 0 :
            answer += high[(low.find(i) + k) % 26]
        if high.count(i) != 0 :
            answer += low[(high.find(i) + k) % 26]
        if emo1.count(i) != 0 :
            answer += emo2[(emo1.find(i) + k) % 16]
        if emo2.count(i) != 0 :
            answer += emo1[(emo2.find(i) + k) % 26]
    print('암호화 결과 : ', answer)

def decrypt(answer) :
    m = input('message 입력 : ')
    k = int(input('key 입력 : '))        
    for i in m :
        #message의 값 i가 입력된 경우의 수로 진행
        #i의 값을 경우의 수의 리스트의 인덱스(수) 값에
        #key값을 더한 후 26의 나머지의 값을
        #암호화할 리스트의 인덱스 값(문자)을 answer에 대입
        if low.count(i) != 0 :
            answer += high[(low.find(i) - k) % 26]
        if high.count(i) != 0 :
            answer += low[(high.find(i) - k) % 26]
        if emo1.count(i) != 0 :
            answer += emo2[(emo1.find(i) - k) % 16]
        if emo2.count(i) != 0 :
            answer += emo1[(emo2.find(i) - k) % 16]
    print('암호화 결과 : ', answer)

start()
